from tkinter import *
from tkinter import ttk, messagebox
from time import strftime
from datetime import datetime
i=0
def update_clock():
    current_time = strftime('%H:%M:%S %p')
    clock_label['text'] = f'Time: {current_time}'
    clock_label.after(1000, update_clock)

def access_student():
    name = user_name_input_area.get()
    global ID
    ID = user_password_entry_area.get()

    if len(name) < 3 or name == "" or name[0] != "S":
        messagebox.showerror("Error", "ERROR: Please enter a valid username starting with 'S-'")
    elif len(ID) != 9 or not ID.isdigit():
        messagebox.showerror("Error", "ERROR: Please enter a valid 9-digit ID")
    else:
        with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\add_member.txt", "r") as file:
            lines = file.readlines()
            for line in lines:
                if f"ID: {ID}" in line:
                    success_box = messagebox.showinfo("Success", "Student login successful")
                    with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\log_in.txt", "a") as file:
                        file.write(f"{ID} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        if success_box:
            student_page = Tk()
            student_page.geometry("790x560")
            student_page.configure(bg="#000000")

            welcome_label = Label(student_page, text=f"Hello, {name}!", background="#1dd7f3", font=(None, 17), width=60, height=2)
            welcome_label.grid(row=1, column=1, columnspan=3, pady=20)

            button_frame = Frame(student_page, bg="#000000")
            button_frame.grid(row=2, column=1, pady=20)

            style = ttk.Style()
            style.configure("TButton", padding=(10, 5, 10, 5), font='Helvetica 12 bold')

            todo_btn_1 = ttk.Button(button_frame, text="To-Do List", command=lambda: todolist(student_page))
            todo_btn_1.grid(row=0, column=0, padx=10)

            assignments_btn = ttk.Button(button_frame, text="View Assignments", command=View_Assignments_S)
            assignments_btn.grid(row=0, column=1, padx=10)

            grades_btn = ttk.Button(button_frame, text="View Grades and GPA", command=View_Grades_and_GPA_S)
            grades_btn.grid(row=0, column=2, padx=10)

            courses_btn = ttk.Button(button_frame, text="View Courses", command=View_courses_S)
            courses_btn.grid(row=0, column=3, padx=10)

            fees_btn = ttk.Button(button_frame, text="View Fees", command=View_fees_S)
            fees_btn.grid(row=0, column=4, padx=10)

            Access.destroy() 

            clock_frame = Frame(student_page, bg="#000000")
            clock_frame.grid(row=3, column=1, pady=20)

            global clock_label
            clock_label = Label(clock_frame, font=('calibri', 14, 'bold'), background="#000000", foreground="#1dd7f3")
            clock_label.grid(row=0, column=0)

            update_clock()  

            day_label = Label(clock_frame, text=f'Day: {datetime.now().strftime("%A")}', font=('calibri', 14, 'bold'), background="#000000", foreground="#1dd7f3")
            day_label.grid(row=0, column=1)

            student_page.mainloop()


def View_Assignments_S():
    assignments = []
    with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\Student_ass.txt", "r") as file:
        lines = file.readlines()
        for line in lines:
            if ID[-1] in line:
                assignments.append(line)
            else:
                print("0")


    print("Assignments:", assignments)

    assignments_window = Tk()
    assignments_window.geometry("790x560")
    assignments_window.title("Assignments")
    assignments_window.configure(bg="#000000")

    label_title = Label(assignments_window, text="Assignments", background="#1dd7f3", font=(None, 17), width=20, height=1)
    label_title.grid(row=1, column=1, pady=10, columnspan=2)

    for i, assignment in enumerate(assignments, start=2):
        assignment_label = Label(assignments_window, text=assignment, background="#ffffff", width=100, height=12)
        assignment_label.grid(row=i, column=1, pady=5, columnspan=2)

    assignments_window.mainloop()


def View_Grades_and_GPA_S():
    GPA_S=[]
    with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\GPA.txt", "r") as file:
        lines = file.readlines()
        for line in lines:
            if ID in line:
                GPA_S.append(line)
                break
        else:
            gpa_label_text = "No GPA information available."

    gpa_window = Tk()
    gpa_window.geometry("790x560")
    gpa_window.title("Grades and GPA")
    gpa_window.configure(bg="#000000")

    label_title = Label(gpa_window, text="Grades and GPA", background="#1dd7f3", font=(None, 17), width=20, height=1)
    label_title.grid(row=1, column=1, pady=10, columnspan=2)

    gpa_label = Label(gpa_window, text=GPA_S, background="#ffffff", width=100, height=12)
    gpa_label.grid(row=2, column=1, pady=10, columnspan=2)

    gpa_window.mainloop()


def View_courses_S():

    with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\add_member.txt", "r") as file:
        lines = file.readlines()
        for line in lines:
            if ID in line:
                courses_info = line.split(',')[5]
                courses_label_text = f"{courses_info}"
                break
        else:
            courses_label_text = "No course information available."

    courses_window = Tk()
    courses_window.geometry("500x150")
    courses_window.title("Courses")
    courses_window.configure(bg="#000000")

    label_title = Label(courses_window, text="Courses", background="#1dd7f3", font=(None, 17), width=20, height=1)
    label_title.grid(row=1, column=1, pady=10, columnspan=2)

    courses_label = Label(courses_window, text=courses_label_text, background="#ffffff", width=60, height=6)
    courses_label.grid(row=2, column=1, pady=10, columnspan=2)

    courses_window.mainloop()

def View_fees_S():

    with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\add_member.txt", "r") as file:
        lines = file.readlines()
        for line in lines:
            if ID in line:
                fees_info = line.split(',')[6]
                fees_label_text = f"{fees_info}"
                break
        else:
            fees_label_text = "No fee information available."

    fees_window = Tk()
    fees_window.geometry("500x150")
    fees_window.title("Fees")
    fees_window.configure(bg="#000000")

    label_title = Label(fees_window, text="Fees", background="#1dd7f3", font=(None, 17), width=20, height=1)
    label_title.grid(row=1, column=1, pady=10, columnspan=2)

    fees_label = Label(fees_window, text=fees_label_text, background="#ffffff", width=40, height=1)
    fees_label.grid(row=2, column=1, pady=10, columnspan=2)

    fees_window.mainloop()

def todolist(previous_page):
    tasks = []

    def add_task():
        name_task = name_task_input_area.get()
        description_task = description_task_input_area.get()
        deadline_task = deadline_task_input_area.get()

        task = {
            'name': name_task,
            'description': description_task,
            'deadline': deadline_task,
            'completed': False
        }

        tasks.append(task)
        update_task_list()

    def update_task_list():
        task_list.delete(0, END)
        for i, task in enumerate(tasks, start=1):
            status = "Completed" if task['completed'] else "Not Completed"
            task_list.insert(END, f"{i}. {task['name']} - {task['description']} - {task['deadline']} - Status: {status}")

    def mark_as_complete():
        selected_tasks = task_list.curselection()
        for index in selected_tasks:
            tasks[index]['completed'] = True
        update_task_list()

    def remove_task():
        selected_tasks = task_list.curselection()
        for index in reversed(selected_tasks):
            tasks.pop(index)
        update_task_list()

    def save_tasks():
        with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\todo.txt", "a") as file:
            for task in tasks:
                file.write(f"Task: {task['name']}, Description: {task['description']}, Deadline: {task['deadline']}, Completed: {task['completed']}\n")

    previous_page.destroy()
    todo_page = Tk()
    todo_page.geometry("990x560")
    todo_page.title("To-Do List")
    todo_page.configure(bg="#000000")
    top_label1 = Label(todo_page, text="", background="#1dd7f3", width=25, font=(None, 17), height=1).grid(row=0, column=0, pady=0)
    top_label2 = Label(todo_page, text="TAKA", background="#ffffff", width=25, font=(None, 17), height=1).grid(row=0, column=1, pady=0)
    top_label3 = Label(todo_page, text="", background="#1dd7f3", width=25, font=(None, 17), height=1).grid(row=0, column=2, pady=0)

    task_list = Listbox(todo_page, selectmode=MULTIPLE, width=40, height=15, selectbackground="lightblue", exportselection=0)
    task_list.grid(row=1, column=0, pady=10)

    details_frame = Frame(todo_page, bg="#1dd7f3")
    details_frame.grid(row=1, column=1, pady=10, padx=10)

    name_task_label = Label(details_frame, text="Task Name:")
    name_task_label.grid(row=0, column=0, pady=5, padx=5)
    name_task_input_area = Entry(details_frame, width=30)
    name_task_input_area.grid(row=0, column=1, pady=5, padx=5)

    description_task_label = Label(details_frame, text="Task Description:")
    description_task_label.grid(row=1, column=0, pady=5, padx=5)
    description_task_input_area = Entry(details_frame, width=30)
    description_task_input_area.grid(row=1, column=1, pady=5, padx=5)

    deadline_task_label = Label(details_frame, text="Task Deadline:")
    deadline_task_label.grid(row=2, column=0, pady=5, padx=5)
    deadline_task_input_area = Entry(details_frame, width=30)
    deadline_task_input_area.grid(row=2, column=1, pady=5, padx=5)

    add_task_btn = Button(todo_page, text="Add Task", background="#1dd7f3", command=add_task)
    add_task_btn.grid(row=2, column=1, pady=10)

    mark_as_complete_btn = Button(todo_page, text="Mark as Complete", background="#1dd7f3", command=mark_as_complete)
    mark_as_complete_btn.grid(row=3, column=1, pady=10)

    remove_task_btn = Button(todo_page, text="Remove Task", command=remove_task, background="#1dd7f3")
    remove_task_btn.grid(row=4, column=1, pady=10)

    save_tasks_btn = Button(todo_page, text="Save Tasks", command=save_tasks, background="#1dd7f3")
    save_tasks_btn.grid(row=5, column=1, pady=10)

    update_task_list()

def access_admin():
    name = user_name_input_area.get()
    ID = user_password_entry_area.get()
    if name != "0" or not name.isdigit() or ID != "0" or not ID.isdigit():
        messagebox.showerror("Error", "Invalid input for admin login")
    else:
        success_box = messagebox.showinfo("Success", "ADMIN 0000 login successful")
        if success_box:
            admin_page = Tk()
            admin_page.geometry("790x260")
            admin_page.configure(bg="#000000")
            top_label1= Label(admin_page, text="", background="#1dd7f3", width=20, font=(None, 17), height=1).grid(row=0, column=1, pady=0)
            top_label2 = Label(admin_page, text="TAKA", background="#ffffff", width=20, font=(None, 17), height=1).grid(row=0, column=2, pady=0)
            top_label3 = Label(admin_page, text="", background="#1dd7f3", width=20, font=(None, 17), height=1).grid(row=0, column=3, pady=0)

            add_new_member_btn = Button(admin_page, text="Add New Member", command=lambda: add_new_member(admin_page))
            add_new_member_btn.grid(row=3, column=1, pady=10)
            Access.destroy()  # Close the previous page

def add_new_member(add_new_member_window):
    add_new_member_window.geometry("790x460")
    add_new_member_window.title("Add New Member")
    add_new_member_window.configure(bg="#000000")

    Name_label = Label(add_new_member_window, text="Enter Name:")
    Name_label.grid(row=1, column=1, pady=10)
    Name_input_area = Entry(add_new_member_window, width=20)
    Name_input_area.grid(row=1, column=2, pady=10)

    phone_number_label = Label(add_new_member_window, text="Phone Number:")
    phone_number_label.grid(row=2, column=1, pady=10)
    phone_number_input_area = Entry(add_new_member_window, width=20)
    phone_number_input_area.grid(row=2, column=2, pady=10)

    ID_label = Label(add_new_member_window, text="ID:")
    ID_label.grid(row=3, column=1, pady=10)
    ID_input_area = Entry(add_new_member_window, width=20)
    ID_input_area.grid(row=3, column=2, pady=10)

    Age_label = Label(add_new_member_window, text="Age:")
    Age_label.grid(row=4, column=1, pady=10)
    Age_input_area = Entry(add_new_member_window, width=20)
    Age_input_area.grid(row=4, column=2, pady=10)

    Mail_label = Label(add_new_member_window, text="Mail:")
    Mail_label.grid(row=5, column=1, pady=10)
    Mail_input_area = Entry(add_new_member_window, width=20)
    Mail_input_area.grid(row=5, column=2, pady=10)

    course_label = Label(add_new_member_window, text="Course with(-):")
    course_label.grid(row=6, column=1, pady=10)
    course_input_area = Entry(add_new_member_window, width=20)
    course_input_area.grid(row=6, column=2, pady=10)

    fees_label = Label(add_new_member_window, text="Fees:")
    fees_label.grid(row=7, column=1, pady=10)
    fees_input_area = Entry(add_new_member_window, width=20)
    fees_input_area.grid(row=7, column=2, pady=10)

    type_label = Label(add_new_member_window, text="type instructor or student:")
    type_label.grid(row=8, column=1, pady=10)
    type_input_area = Entry(add_new_member_window, width=20)
    type_input_area.grid(row=8, column=2, pady=10)

    def save_add_member():
        type=type_input_area.get()
        Name = Name_input_area.get()
        phone_number = phone_number_input_area.get()
        ID = ID_input_area.get()
        Age = Age_input_area.get()
        Mail = Mail_input_area.get()
        course = course_input_area.get()
        fees = fees_input_area.get()
        add_member=(f"Name: {Name}, Phone Number: {phone_number}, ID: {ID}, Age: {Age}, Mail: {Mail}, Course: {course}, Fees: {fees},type:{type}")
        with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\add_member.txt", "a") as file:
          file.write(add_member+ "\n")
        success_box = messagebox.showinfo("Success", "DATA SAVED")
        add_new_member_window.destroy()

    save_btn = Button(add_new_member_window, text="Save Member", command=save_add_member)
    save_btn.grid(row=8, column=1, columnspan=2, pady=10)


def access_instructor():
    name = user_name_input_area.get()
    ID = user_password_entry_area.get()

    if len(name) < 3 or name == "" or name[0] != "T":
        messagebox.showerror("Error", "ERROR: Please enter a valid username starting with 'T-'")
    elif len(ID) != 4 or not ID.isdigit():
        messagebox.showerror("Error", "ERROR: Please enter a valid 4-digit ID")
    else:
     with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\add_member.txt", "r") as file:
        lines = file.readlines()
        for line in lines:
         if f"ID: {ID}" in line:
           success_box = messagebox.showinfo("Success", "Instructor login successful")
           if success_box:
            Instructor_page = Tk()
            Instructor_page.geometry("790x560")
            Instructor_page.configure(bg="#000000")
            top_label1= Label(Instructor_page, text="", background="#1dd7f3", width=20, font=(None, 17), height=1).grid(row=1, column=1, pady=0)
            top_label2 = Label(Instructor_page, text="TAKA", background="#ffffff", width=20, font=(None, 17), height=1).grid(row=1, column=2, pady=0)
            top_label3 = Label(Instructor_page, text="", background="#1dd7f3", width=20, font=(None, 17), height=1).grid(row=1, column=3, pady=0)

            gpa_btn = Button(Instructor_page, text="Enter grades students", command=lambda: GPAcalc(Instructor_page))
            gpa_btn.grid(row=3, column=1, pady=10)
            add_ass_btn = Button(Instructor_page, text="Add Assignment", command=lambda: add_ass(Instructor_page))
            add_ass_btn.grid(row=4, column=1, pady=10)
            Access.destroy()  

def add_ass(instructor_page):
    add_ass_window = Tk()
    add_ass_window.geometry("790x450")
    add_ass_window.title("Add Assignment")
    add_ass_window.configure(bg="#000000")

    top_label1= Label(add_ass_window, text="", background="#1dd7f3", width=20, font=(None, 17), height=1).grid(row=1, column=1, pady=0)
    top_label2 = Label(add_ass_window, text="TAKA", background="#ffffff", width=20, font=(None, 17), height=1).grid(row=1, column=2, pady=0)
    top_label3 = Label(add_ass_window, text="", background="#1dd7f3", width=20, font=(None, 17), height=1).grid(row=1, column=3, pady=0)
    group_label = Label(add_ass_window, text="Enter IDs with(,):")
    group_label.grid(row=2, column=1, pady=10)

    group_input_area = Entry(add_ass_window, width=20)
    group_input_area.grid(row=2, column=2, pady=10)

    name_ass_label = Label(add_ass_window, text="Assignment Name:")
    name_ass_label.grid(row=3, column=1, pady=10)

    name_ass_input_area = Entry(add_ass_window, width=20)
    name_ass_input_area.grid(row=3, column=2, pady=10)

    description_ass_label = Label(add_ass_window, text="Assignment Description:")
    description_ass_label.grid(row=4, column=1, pady=10)

    description_ass_input_area = Entry(add_ass_window, width=20)
    description_ass_input_area.grid(row=4, column=2, pady=10)

    deadline_ass_label = Label(add_ass_window, text="Assignment Deadline:")
    deadline_ass_label.grid(row=5, column=1, pady=10)

    deadline_ass_input_area = Entry(add_ass_window, width=20)
    deadline_ass_input_area.grid(row=5, column=2, pady=10)

    def save_assignment():
        i=0
        group_number = group_input_area.get()
        assignment_name = name_ass_input_area.get()
        assignment_description = description_ass_input_area.get()
        assignment_deadline = deadline_ass_input_area.get()
        Student_ass =(f"Group: {group_number}, Assignment Name: {assignment_name}, Description: {assignment_description}, Deadline: {assignment_deadline}\n")
        with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\Student_ass.txt", "a") as file:
          file.write(Student_ass+ "\n")
        success_box = messagebox.showinfo("Success", "Assignment SAVED")


    save_btn = Button(add_ass_window, text="Save Assignment", command=save_assignment)
    save_btn.grid(row=6, column=1, pady=10)

def submit_selection():
    selection = user_selection.get()
    if selection == "Student":
        access_student()
    elif selection == "Instructor":
        access_instructor()
    else: 
        access_admin()    

def GPAcalc(previous_page):
    GPA_page = Tk()
    GPA_page.geometry("790x450")
    GPA_page.configure(bg="#000000")
    top_label1= Label(GPA_page, text="", background="#1dd7f3", width=20, font=(None, 17), height=1).grid(row=1, column=1, pady=0)
    top_label2 = Label(GPA_page, text="TAKA", background="#ffffff", width=20, font=(None, 17), height=1).grid(row=1, column=2, pady=0)
    top_label3 = Label(GPA_page, text="", background="#1dd7f3", width=20, font=(None, 17), height=1).grid(row=1, column=3, pady=0)
 

    ID_label = Label(GPA_page, text="Enter ID of student:")
    ID_label.grid(row=2, column=1, pady=10)

    ID_input_area = Entry(GPA_page, width=30)
    ID_input_area.grid(row=2, column=2, pady=10)

    grades_label = Label(GPA_page, text="Enter grades (separated by commas):")
    grades_label.grid(row=3, column=1, pady=10)

    grades_input_area = Entry(GPA_page, width=30)
    grades_input_area.grid(row=3, column=2, pady=10)

    def calculate_and_display():
        student_id = ID_input_area.get()
        grades_text = grades_input_area.get().upper().replace(" ", "")
        grades_list = grades_text.split(',')

        total_points = 0
        total_credits = 0

        grades = {
            'A': 4.0,
            'A-': 3.66,
            'B+': 3.33,
            'B': 3.0,
            'B-': 2.66,
            'C+': 2.33,
            'C': 2.0,
            'C-': 1.66,
            'D+': 1.33,
            'D': 1.00,
            'D-': 0.66,
            'F': 0.00
        }

        for grade in grades_list:
            if grade.strip() in grades:
                total_points += grades[grade.strip()]
                total_credits += 1
            else:
                result_label.config(text=f"Invalid grade: {grade.strip()}")
                return

        if total_credits > 0:
            calculated_gpa = total_points / total_credits
            result_label.config(text=f"GPA for {student_id}: {calculated_gpa:.2f}")
            with open(r"C:\Users\DELL\OneDrive\Desktop\TASKCODE V2.2\TASKCODE\GPA.txt", "a") as file:
              file.write(f"{i+1})ID: {student_id}, GPA: {calculated_gpa:.2f}, Grades:{','.join(grades_list)}\n")
        else:
            result_label.config(text="Invalid grades")

    calculate_btn = Button(GPA_page, text="Calculate GPA", command=calculate_and_display)
    calculate_btn.grid(row=4, column=1, pady=10)

    result_label = Label(GPA_page, text="")
    result_label.grid(row=4, column=2, pady=10)

    previous_page.destroy()

Access = Tk()
Access.geometry("790x560")
Access.configure(bg="#000000")
top_label1= Label(Access, text="", background="#1dd7f3", width=20, font=(None, 17), height=1).grid(row=1, column=1, pady=0)
top_label2 = Label(Access, text="TAKA", background="#ffffff", width=20, font=(None, 17), height=1).grid(row=1, column=2, pady=0)
top_label3 = Label(Access, text="", background="#1dd7f3", width=20, font=(None, 17), height=1).grid(row=1, column=3, pady=0)

b_label1= Label(Access, text="Devolp", background="#1dd7f3", font=(None, 17),width=20, height=1).grid(row=20, column=1, pady=239)
b_label2 = Label(Access, text="by", background="#ffffff", font=(None, 17), height=1,width=20).grid(row=20, column=2, pady=239)
b_label3 = Label(Access, text="taskcode", background="#1dd7f3",  font=(None, 17),width=20, height=1).grid(row=20, column=3, pady=239)

selection_label = Label(Access, text="Select User Type:",font=(None, 10),background="#1dd7f3",width=18, height=1)
selection_label.grid(row=3, column=1, pady=10)

user_selection = StringVar(Access)
user_selection.set("Student")

selection_entry = OptionMenu(Access, user_selection, "Student", "Instructor","admin")
selection_entry.grid(row=3, column=2, pady=20)

name_label = Label(Access, text="Username", background="#1dd7f3",width=20, height=1)
name_label.grid(row=4, column=1, pady=20)

id_label = Label(Access, text="ID", background="#1dd7f3",width=20, height=1)
id_label.grid(row=5, column=1, pady=20)

submit_button = Button(Access, text="Submit", command=submit_selection, background="#1dd7f3",width=20, height=1)
submit_button.grid(row=6, column=2, columnspan=1, pady=20)

user_name_input_area = Entry(Access, width=30)
user_name_input_area.grid(row=4, column=2, pady=20)

user_password_entry_area = Entry(Access, width=30)
user_password_entry_area.grid(row=5, column=2, pady=20)

b_label1= Label(Access, text="Devolp", background="#1dd7f3", font=(None, 17),width=20, height=1).grid(row=20, column=1, pady=239)
b_label2 = Label(Access, text="by", background="#1dd7f3", font=(None, 17), height=1,width=20).grid(row=20, column=2, pady=239)
b_label3 = Label(Access, text="taskcode", background="#1dd7f3",  font=(None, 17),width=20, height=1).grid(row=20, column=3, pady=239)
Access.mainloop()

